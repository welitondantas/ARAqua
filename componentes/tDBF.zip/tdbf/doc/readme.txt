TDbf readme:

See history.txt for changelog.
See history.txt for version number, latest version is at the top.
See INSTALL for installation procedure.
License is LGPL (Library General Public License); see COPYING.LIB for details.
